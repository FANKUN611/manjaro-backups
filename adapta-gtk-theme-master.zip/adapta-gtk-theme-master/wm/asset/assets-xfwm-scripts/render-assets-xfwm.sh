#! /bin/bash
#
# This file is part of adapta-gtk-theme
#
# Copyright (C) 2016-2017 Tista <tista.gma500@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#

. "recolor-assets-xfwm.sh"
. "render-assets-xfwm-button.sh"
. "render-assets-xfwm-edge.sh"
. "render-assets-xfwm-title.sh"

exit 0
